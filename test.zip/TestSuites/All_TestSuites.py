import unittest
from testCases.LoginTest import LoginTest

tc1=unittest.TestLoader().loadTestsFromTestCase(LoginTest)


sanityTestSuite=unittest.TestSuite([tc1])


unittest.TextTestRunner(verbosity=1).run(sanityTestSuite)