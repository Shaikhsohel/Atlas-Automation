import unittest
import HtmlTestRunner
from selenium import webdriver
import time
import sys
sys.path.append("C://Users/lenovo/PycharmProjects/AtlastPOM_FrameWork")
from pageObjects.LoginPage import LoginPage
class LoginTest(unittest.TestCase):
    baseURL = "https://gkblabssandbox.wshcgroup.com/"
    username = "amar@gkblabs.com"
    password = "amar@gkblabs.com"
    driver=webdriver.Chrome(executable_path="C:\\Users\\lenovo\\PycharmProjects\\AtlastPOM_FrameWork\\drivers\\chromedriver.exe")
    username2 = "amar@gkblabs.com"
    password2 = "amar@gkblabs.com"
    @classmethod
    def setUp(self):
        self.driver.get(self.baseURL)
        self.driver.maximize_window()
    def test_login(self):
        lp = LoginPage(self.driver)
        time.sleep(5)
        lp.setUserName(self.username)
        lp.setPassword(self.password)
        lp.clickLogin()
        time.sleep(5)   
        self.assertEqual("Well States Health Care", self.driver.title, "webpage title is not matching")

    def test_logintwo(self):
        lp = LoginPage(self.driver)
        time.sleep(5)
        lp.setUserName(self.username2)
        lp.setPassword(self.password2)
        lp.clickLogin()
        time.sleep(5)
        self.assertEqual("Well States Health Care", self.driver.title, "webpage title is not matching")
    @classmethod
    def tearDown(self):
        self.driver.close()


if __name__== '__main__':
    unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output='C:/Users/lenovo/PycharmProjects/AtlastPOM_FrameWork/reports'))