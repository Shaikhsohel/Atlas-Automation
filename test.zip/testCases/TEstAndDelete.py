import XLUtils
from selenium import webdriver
import time
driver=webdriver.Chrome(executable_path="C:\\Users\\lenovo\\PycharmProjects\\AtlastPOM_FrameWork\\drivers\\chromedriver.exe")
driver.maximize_window()
driver.get("https://gkblabssandbox.wshcgroup.com/")
time.sleep(5)
path="C://Users/lenovo/PycharmProjects/AtlastPOM_FrameWork/drivers/Login1.xlsx"
rows=XLUtils.getRowCount(path,'Sheet1')
for r in range(2,rows+1):
    username = XLUtils.readData(path, "Sheet1",r, 1)
    password = XLUtils.readData(path, "Sheet1",r, 2)
    driver.find_element_by_id("username").send_keys(username)
    driver.find_element_by_id("password").send_keys(password)
    driver.find_element_by_xpath("/html/body/div[1]/div/form/button").click()
    if driver.title=="Well States Health Care":
        print("test case pass")
        XLUtils.writeData(path,"Sheet1",r,3,"test pass")
    else:
        print("test case pass")
        XLUtils.writeData(path, "Sheet1", r, 3, "test fail")

    driver.close()
    driver.quit()





