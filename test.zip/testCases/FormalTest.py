from selenium import webdriver
import time
from selenium.webdriver.common.keys import Keys

driver=webdriver.Chrome(executable_path="C:\\Users\\lenovo\\PycharmProjects\\AtlastPOM_FrameWork\\drivers\\chromedriver.exe")

driver.get("https://gkblabssandbox.wshcgroup.com/")
driver.find_element_by_id("username").send_keys("amar@gkblabs.com")
driver.find_element_by_id("password").send_keys("amar@gkblabs.com")
driver.find_element_by_xpath("/html/body/div[1]/div/form/button").click()
time.sleep(5)
driver.find_element_by_css_selector("body > div.container > div.right.content-page > div.header.content.rows-content-header > div > div > div.navbar-collapse.collapse > ul > li:nth-child(4) > a > strong").click()
time.sleep(3)
driver.find_element_by_xpath("/html/body/div[1]/div[3]/div[1]/div/div/div[2]/ul/li[4]/ul/li[2]/a").click()
driver.close()
