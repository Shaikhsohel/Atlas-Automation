class LoginPage():
    tesxtbox_username_id="username"
    tesxtbox_password_id="password"
    button_login_xpath="/html/body/div[1]/div/form/button"

    def __init__(self,driver):
        self.driver=driver

    def setUserName(self,username):
        self.driver.find_element_by_id(self.tesxtbox_username_id).send_keys(username)
    def setPassword(self,password):
        self.driver.find_element_by_id(self.tesxtbox_password_id).send_keys(password)
    def clickLogin(self):
        self.driver.find_element_by_xpath(self.button_login_xpath).click()
