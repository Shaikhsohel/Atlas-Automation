class HomePage():
    text_admin_xpath = "body > div.container > div.right.content-page > div.header.content.rows-content-header > div > div > div.navbar-collapse.collapse > ul > li:nth-child(4) > a > strong"
    button_logout_xpath = "body > div.container > div.right.content-page > div.header.content.rows-content-header > div > div > div.navbar-collapse.collapse > ul > li.dropdown.open > ul > li:nth-child(2) > a"


    def __init__(self,driver):
        self.driver=driver

    def clickAdminText(self):
        self.driver.find_element_by_xpath(self.text_admin_xpath).click()
    def clickLogout(self):
        self.driver.find_element_by_xpath(self.button_logout_xpath).click()